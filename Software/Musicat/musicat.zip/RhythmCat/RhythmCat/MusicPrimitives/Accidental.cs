using System;
using System.Collections.Generic;
using System.Text;

namespace MusicPrimitives {
	public enum Accidental {
		Natural,
		Flat,
		Sharp,
		DoubleFlat,
		DoubleSharp
	}
}
