// Static Model

namespace MusicPrimitives 
{
	public enum Alteration
	{
		None,
		Raised,
		Lowered,
		Augmented,
		Diminished
	}

}