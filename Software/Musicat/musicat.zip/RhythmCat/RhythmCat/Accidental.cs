﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RhythmcCat {
	public enum Accidental {
		Natural,
		Flat,
		Sharp,
		DoubleFlat,
		DoubleSharp
	}
}
